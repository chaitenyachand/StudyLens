'''' import streamlit as st
import PyPDF2
import torch
from transformers import pipeline

@st.cache_resource
def load_pipeline():
    return pipeline("text2text-generation", model="humarin/chatgpt_paraphraser_on_T5_base", device=0 if torch.cuda.is_available() else -1)

generator = load_pipeline()

def extract_text_from_pdf(file):
    pdf_reader = PyPDF2.PdfReader(file)
    extracted_text = " ".join([page.extract_text() for page in pdf_reader.pages if page.extract_text()])
    return extracted_text

def generate_flashcards_with_ai(text, chunk_size=500):
    flashcards = []
    for i in range(0, len(text), chunk_size):
        chunk = text[i:i+chunk_size]
        prompt = f"Generate flashcards in format 'Question: ; Answer: ' based on the following text:\n\n{chunk}\n\nFlashcards:"
        result = generator(prompt, max_length=512, do_sample=False)[0]['generated_text']

        qa_pairs = result.split('\n')
        for pair in qa_pairs:
            if "Question:" in pair and "Answer:" in pair:
                try:
                    question = pair.split('Question:')[1].split('Answer:')[0].strip()
                    answer = pair.split('Answer:')[1].strip()
                    flashcards.append((question, answer))
                except:
                    pass
    return flashcards

def app():
    st.title('🃏 AI Flashcard Generator (with Playing Card Flip)')

    uploaded_file = st.file_uploader('Upload your PDF file', type='pdf')

    if uploaded_file:
        with st.spinner('Extracting text...'):
            pdf_text = extract_text_from_pdf(uploaded_file)
        
        if st.button('Generate Flashcards'):
            with st.spinner('Generating flashcards using AI...'):
                flashcards = generate_flashcards_with_ai(pdf_text)

            if flashcards:
                st.success(f'✅ Generated {len(flashcards)} flashcards!')
                
                st.markdown(
                    """
                    <style>
                    .card {
                      background-color: transparent;
                      width: 300px;
                      height: 200px;
                      perspective: 1000px;
                      display: inline-block;
                      margin: 20px;
                    }

                    .card-inner {
                      position: relative;
                      width: 100%;
                      height: 100%;
                      text-align: center;
                      transition: transform 0.8s;
                      transform-style: preserve-3d;
                      box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
                    }

                    .card:hover .card-inner {
                      transform: rotateY(180deg);
                    }

                    .card-front, .card-back {
                      position: absolute;
                      width: 100%;
                      height: 100%;
                      backface-visibility: hidden;
                      border: 1px solid #ccc;
                      border-radius: 10px;
                      padding: 20px;
                      background: #f8f9fa;
                      overflow: auto;
                    }

                    .card-back {
                      background-color: #4CAF50;
                      color: white;
                      transform: rotateY(180deg);
                    }
                    </style>
                    """,
                    unsafe_allow_html=True
                )

                for idx, (question, answer) in enumerate(flashcards):
                    card_html = f"""
                    <div class="card">
                      <div class="card-inner">
                        <div class="card-front">
                          <h4>Q{idx+1}</h4>
                          <p>{question}</p>
                        </div>
                        <div class="card-back">
                          <h4>Answer</h4>
                          <p>{answer}</p>
                        </div>
                      </div>
                    </div>
                    """
                    st.markdown(card_html, unsafe_allow_html=True)
            else:
                st.error("No flashcards could be generated.")
'''

''' import streamlit as st
import PyPDF2
import openai
import os
import base64

# YOUR OpenAI API Key
openai.api_key = "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"  # 👈 Replace with your real key

def extract_text_from_pdf(file):
    pdf_reader = PyPDF2.PdfReader(file)
    extracted_text = " ".join([page.extract_text() or "" for page in pdf_reader.pages])
    return extracted_text.strip()

def split_text_into_chunks(text, chunk_size):
    chunks = []
    start = 0
    end = chunk_size
    while start < len(text):
        chunk = text[start:end]
        chunks.append(chunk)
        start = end
        end += chunk_size
    return chunks

def generate_anki_flashcards(text, chunk_size, model_choice):
    text_chunks = split_text_into_chunks(text, chunk_size)
    flashcards = []
    for i, chunk in enumerate(text_chunks):
        message_prompt = [
            {"role": "system", "content": "You are a helpful assistant and specialist in creating flashcards."},
            {"role": "user", "content": f"Create 5 flashcards from the following text. Each flashcard should be in 'Question: ... Answer: ...' format. Keep them concise. Text: {chunk}"}
        ]

        api_response = openai.chat.completions.create(
            model=model_choice,
            messages=message_prompt,
            temperature=0.2,
            max_tokens=2048
        )

        generated_text = api_response['choices'][0]['message']['content'].strip()

        # Split into individual cards
        cards = []
        for line in generated_text.split('\n'):
            if 'Question:' in line and 'Answer:' in line:
                q_part = line.split('Question:')[1].split('Answer:')[0].strip()
                a_part = line.split('Answer:')[1].strip()
                cards.append((q_part, a_part))
        
        flashcards.extend(cards)

        # Optional: Remove this `break` to generate for all chunks
        break

    return flashcards

def get_file_download_link(cards, filename):
    flashcards_text = '\n'.join([f"{q};{a}" for q, a in cards])
    b64 = base64.b64encode(flashcards_text.encode()).decode()
    return f'<a href="data:file/txt;base64,{b64}" download="{filename}">Download Flashcards</a>'

def app():
    st.title('🃏 Anki-Style Flashcard Generator')

    uploaded_file = st.file_uploader('Please upload your PDF file', type='pdf')

    chunk_size = st.number_input('Enter the chunk size (default is 1000)', min_value=1, value=1000, step=1)

    model_choice = st.selectbox('Select the AI model to be used', ['gpt-3.5-turbo', 'gpt-4'])

    if uploaded_file is None:
        st.error('Please upload a PDF file before proceeding.')
    elif st.button('Generate Flashcards'):
        pdf_text = extract_text_from_pdf(uploaded_file)

        if not pdf_text:
            st.warning('No extractable text found in the PDF. Please try another file.')
            st.stop()

        flashcards = generate_anki_flashcards(pdf_text, chunk_size, model_choice)

        if not flashcards:
            st.warning('No flashcards were generated. Try adjusting chunk size or a different PDF.')
            st.stop()

        st.success('Flashcards successfully created!')

        # Display Flashcards
        st.subheader("📚 Flashcards Preview")
        for idx, (front, back) in enumerate(flashcards, 1):
            with st.expander(f"Flashcard {idx} - Front: {front}"):
                st.write(f"**Back:** {back}")

        # Download Link
        download_link = get_file_download_link(flashcards, 'flashcards.txt')
        st.markdown(download_link, unsafe_allow_html=True)

# Run the app
if __name__ == "__main__":
    app()'''

import streamlit as st
import PyPDF2
import openai
import base64
from openai import OpenAI  # NEW

# Initialize OpenAI client
client = OpenAI(
    api_key="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"
)

def extract_text_from_pdf(file):
    pdf_reader = PyPDF2.PdfReader(file)
    extracted_text = " ".join([page.extract_text() or "" for page in pdf_reader.pages])
    return extracted_text.strip()

def split_text_into_chunks(text, chunk_size):
    return [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)]

def generate_anki_flashcards(text, chunk_size, model_choice):
    text_chunks = split_text_into_chunks(text, chunk_size)
    flashcards = []

    for i, chunk in enumerate(text_chunks):
        message_prompt = [
            {"role": "system", "content": "You are a helpful assistant and specialist in creating flashcards."},
            {"role": "user", "content": f"Create 5 flashcards from this text. Format: 'Question: ... Answer: ...'. Keep it short and simple.\n\nText:\n{chunk}"}
        ]

        response = client.chat.completions.create(
            model=model_choice,
            messages=message_prompt,
            temperature=0.2,
            max_tokens=2048
        )

        generated_text = response.choices[0].message.content.strip()

        # Split into individual flashcards
        cards = []
        current_question = ""
        current_answer = ""

        for line in generated_text.splitlines():
            line = line.strip()
            if line.lower().startswith("question:"):
                if current_question and current_answer:
                    cards.append((current_question, current_answer))
                    current_answer = ""
                current_question = line[len("question:"):].strip()

            elif line.lower().startswith("answer:"):
                current_answer = line[len("answer:"):].strip()

        if current_question and current_answer:
            cards.append((current_question, current_answer))

        flashcards.extend(cards)

        break  # Process only first chunk

    return flashcards

def get_file_download_link(cards, filename):
    flashcards_text = '\n'.join([f"{q};{a}" for q, a in cards])
    b64 = base64.b64encode(flashcards_text.encode()).decode()
    return f'<a href="data:file/txt;base64,{b64}" download="{filename}">Download Flashcards</a>'

def app():
    st.title('🃏Flashcard Generator')

    uploaded_file = st.file_uploader('Please upload your PDF file', type='pdf')

    chunk_size = st.number_input('Enter the chunk size (default 1000)', min_value=100, value=1000, step=100)

    model_choice = st.selectbox('Select AI model', ['gpt-3.5-turbo', 'gpt-4'])

    if uploaded_file is None:
        st.error('Please upload a PDF file.')
    elif st.button('Generate Flashcards'):
        pdf_text = extract_text_from_pdf(uploaded_file)

        if not pdf_text:
            st.warning('No extractable text found in the PDF.')
            st.stop()

        flashcards = generate_anki_flashcards(pdf_text, chunk_size, model_choice)

        if not flashcards:
            st.warning('No flashcards generated. Try a different PDF or smaller chunk size.')
            st.stop()

        st.success('Flashcards created!')

        # Display Flashcards
        st.subheader("📚 Flashcards Preview")
        for idx, (front, back) in enumerate(flashcards, 1):
            with st.expander(f"Flashcard {idx}: {front}"):
                st.write(f"**Answer:** {back}")

        # Download Link
        download_link = get_file_download_link(flashcards, 'flashcards.txt')
        st.markdown(download_link, unsafe_allow_html=True)

if __name__ == "__main__":
    app()
